/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
/*
 * Copyright (c) 2017 NITK Surathkal
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Authors: Ankit Deepak <adadeepak8@gmail.com>
 *          Shravya K. S. <shravya.ks0@gmail.com>
 *          Mohit P. Tahiliani <tahiliani@nitk.edu.in>
 */

#include "eval-topology.h"
#include "eval-ts.h"

namespace ns3 {

NS_LOG_COMPONENT_DEFINE ("EvaluationTopology");

NS_OBJECT_ENSURE_REGISTERED (EvaluationTopology);

TypeId
EvaluationTopology::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::EvaluationTopology")
    .SetGroupName ("AqmEvaluationSuite")
  ;
  return tid;
}

EvaluationTopology::EvaluationTopology (std::string ScenarioName, uint32_t numFlows,
                                        std::string bwd, Time dly, std::string queueDisc, uint32_t pktSize, bool isBql)
  //: m_dumbbell (numFlows, p2pHelper, numFlows, p2pHelper, p2pHelper) //change
{
  m_numFlows = numFlows;
  m_flowsAdded = 0;
  m_packetSize = pktSize;
  bool m_isBql = isBql;
  
  std::string dataRateRemoteHostLink = bwd;
  std::string coreBandwidth = bwd;   //BottleNeck 
  double bandwidthBand1 = 6000e6;  //6000MHz  Mbps = MHz * 8 ->  48Gbps

  Time delayRemoteHostLink = dly;
  Time coreLatency = dly;
  
  Config::SetDefault("ns3::LteRlcUm::MaxTxBufferSize", UintegerValue(1000000000)); //RLC Unacknowledged Mode (UM),
  uint16_t numerologyBwp1 = 5;
  double centralFrequencyBand1 = 28e9;  //28 GHz  
  double totalTxPower = 35; //dBm
  
  uint16_t gNbNum = 1;
  uint32_t ueNumPergNb = numFlows;
  
  NS_ABORT_IF(centralFrequencyBand1 < 0.5e9 && centralFrequencyBand1 > 100e9);

    

    int64_t randomStream = 1;
    GridScenarioHelper gridScenario;
    gridScenario.SetRows(1);
    gridScenario.SetColumns(gNbNum);
    // All units below are in meters
    gridScenario.SetHorizontalBsDistance(5.0);
    gridScenario.SetVerticalBsDistance(5.0);
    gridScenario.SetBsHeight(1.5);
    gridScenario.SetUtHeight(1.5);
    // must be set before BS number
    gridScenario.SetSectorization(GridScenarioHelper::SINGLE);
    gridScenario.SetBsNumber(gNbNum);
    gridScenario.SetUtNumber(ueNumPergNb * gNbNum);
    gridScenario.SetScenarioHeight(30); // Create a 3x3 scenario where the UE will
    gridScenario.SetScenarioLength(30); // be distribuited.
    randomStream += gridScenario.AssignStreams(randomStream);
    gridScenario.CreateScenario();
    NodeContainer gnb = gridScenario.GetBaseStations();
    NodeContainer ut = gridScenario.GetUserTerminals();

    NodeContainer ueTrafficNodeContainer;

    for (uint32_t j = 0; j < gridScenario.GetUserTerminals().GetN(); ++j)
    {
        Ptr<Node> ue = gridScenario.GetUserTerminals().Get(j);
        { //outFile<<ue<<"\n";
            ueTrafficNodeContainer.Add(ue);
        
        }
    }  

    NS_LOG_INFO("Creating " << gridScenario.GetUserTerminals().GetN() << " user terminals and "
                            << gridScenario.GetBaseStations().GetN() << " gNBs");

    Ptr<NrPointToPointEpcHelper> epcHelper = CreateObject<NrPointToPointEpcHelper>();
    Ptr<IdealBeamformingHelper> idealBeamformingHelper = CreateObject<IdealBeamformingHelper>();
    Ptr<NrHelper> nrHelper = CreateObject<NrHelper>();

    // Put the pointers inside nrHelper
    nrHelper->SetBeamformingHelper(idealBeamformingHelper);
    nrHelper->SetEpcHelper(epcHelper);

    BandwidthPartInfoPtrVector allBwps;
    CcBwpCreator ccBwpCreator;
    const uint8_t numCcPerBand = 1; 

    // Create the configuration for the CcBwpHelper. SimpleOperationBandConf creates
    // a single BWP per CC
    CcBwpCreator::SimpleOperationBandConf bandConf1(centralFrequencyBand1,
                                                    bandwidthBand1,
                                                    numCcPerBand,
                                                    BandwidthPartInfo::UMi_StreetCanyon);
    OperationBandInfo band1 = ccBwpCreator.CreateOperationBandContiguousCc(bandConf1);
    Config::SetDefault("ns3::ThreeGppChannelModel::UpdatePeriod", TimeValue(MilliSeconds(0)));
    nrHelper->SetChannelConditionModelAttribute("UpdatePeriod", TimeValue(MilliSeconds(0)));
    nrHelper->SetPathlossAttribute("ShadowingEnabled", BooleanValue(false));
    nrHelper->InitializeOperationBand(&band1);

    /*
     * Start to account for the bandwidth used by the example, as well as
     * the total power that has to be divided among the BWPs.
     */
    double x = pow(10, totalTxPower / 10);  
    double totalBandwidth = bandwidthBand1;
    allBwps = CcBwpCreator::GetAllBwps({band1});

    Packet::EnableChecking();
    Packet::EnablePrinting();

    /*
     *  Case (i): Attributes valid for all the nodes
     */
    // Beamforming method
    idealBeamformingHelper->SetAttribute("BeamformingMethod",
                                         TypeIdValue(DirectPathBeamforming::GetTypeId()));

    // Core latency
    epcHelper->SetAttribute("S1uLinkDelay", TimeValue(coreLatency/2));
    epcHelper->SetAttribute("S1uLinkDataRate", DataRateValue(DataRate(coreBandwidth)));
    epcHelper->SetAttribute("S5LinkDelay", TimeValue(coreLatency/2));
    epcHelper->SetAttribute("S5LinkDataRate", DataRateValue(DataRate(coreBandwidth)));
    

    // Antennas for all the UEs
    nrHelper->SetUeAntennaAttribute("NumRows", UintegerValue(2));
    nrHelper->SetUeAntennaAttribute("NumColumns", UintegerValue(4));
    nrHelper->SetUeAntennaAttribute("AntennaElement",
                                    PointerValue(CreateObject<IsotropicAntennaModel>()));

    // Antennas for all the gNbs
    nrHelper->SetGnbAntennaAttribute("NumRows", UintegerValue(4));
    nrHelper->SetGnbAntennaAttribute("NumColumns", UintegerValue(8));
    nrHelper->SetGnbAntennaAttribute("AntennaElement",
                                     PointerValue(CreateObject<IsotropicAntennaModel>()));

    //uint32_t bwpId = 0;
    

    // gNb routing between Bearer and bandwidh part
    //nrHelper->SetGnbBwpManagerAlgorithmAttribute(bwpTraffic, UintegerValue(bwpId));

    //NGBR_VIDEO_TCP_DEFAULT
    // Ue routing between Bearer and bandwidth part
    //nrHelper->SetUeBwpManagerAlgorithmAttribute(bwpTraffic, UintegerValue(bwpId));

    /*
     * We miss many other parameters. By default, not configuring them is equivalent
     * to use the default values. Please, have a look at the documentation to see
     * what are the default values for all the attributes you are not seeing here.
     */

    /*
     * Case (ii): Attributes valid for a subset of the nodes
     */

    // NOT PRESENT IN THIS SIMPLE EXAMPLE

    /*
     * We have configured the attributes we needed. Now, install and get the pointers
     * to the NetDevices, which contains all the NR stack:
     */

    NetDeviceContainer enbNetDev =
        nrHelper->InstallGnbDevice(gridScenario.GetBaseStations(), allBwps);
    NetDeviceContainer ueTrafficNetDevContainer = nrHelper->InstallUeDevice(ueTrafficNodeContainer , allBwps);

    randomStream += nrHelper->AssignStreams(enbNetDev, randomStream);
    randomStream += nrHelper->AssignStreams(ueTrafficNetDevContainer, randomStream);
    /*
     * Case (iii): Go node for node and change the attributes we have to setup
     * per-node.
     */

    // Get the first netdevice (enbNetDev.Get (0)) and the first bandwidth part (0)
    // and set the attribute.
    nrHelper->GetGnbPhy(enbNetDev.Get(0), 0)
        ->SetAttribute("Numerology", UintegerValue(numerologyBwp1));
    nrHelper->GetGnbPhy(enbNetDev.Get(0), 0)
        ->SetAttribute("TxPower", DoubleValue(10 * log10((bandwidthBand1 / totalBandwidth) * x))); 


    // When all the configuration is done, explicitly call UpdateConfig ()

    for (auto it = enbNetDev.Begin(); it != enbNetDev.End(); ++it)
    {
        DynamicCast<NrGnbNetDevice>(*it)->UpdateConfig();
    }

    for (auto it = ueTrafficNetDevContainer.Begin(); it != ueTrafficNetDevContainer.End(); ++it)
    {
        DynamicCast<NrUeNetDevice>(*it)->UpdateConfig();
    }

    // From here, it is standard NS3. In the future, we will create helpers
    // for this part as well.




    Ptr<Node> pgw = epcHelper->GetPgwNode();
    Ptr<Node> sgw = epcHelper->GetSgwNode();
    Ptr<Node> gnbptr=gridScenario.GetBaseStations().Get(0);
    NodeContainer remoteHostContainer;
    remoteHostContainer.Create(numFlows);
    
    InternetStackHelper internet;       
    internet.Install(remoteHostContainer);
    
    NodeContainer pgwcontainer = epcHelper->GetPgwNode();
    NodeContainer sgwcontainer = epcHelper->GetSgwNode();
    
    
    
    std::vector<NetDeviceContainer> internetDevices(numFlows);

// Install point-to-point links for each flow

std::vector<PointToPointHelper> p2pHelpers(numFlows);

  // Set attributes for each PointToPointHelper object in the vector
  for (uint32_t i = 0; i < numFlows; ++i) {
    p2pHelpers[i].SetDeviceAttribute("DataRate", DataRateValue(DataRate(dataRateRemoteHostLink)));
    p2pHelpers[i].SetDeviceAttribute("Mtu", UintegerValue(2500));
    p2pHelpers[i].SetChannelAttribute("Delay", TimeValue(delayRemoteHostLink));
    internetDevices[i] = p2pHelpers[i].Install(pgw, remoteHostContainer.Get(i));
  }
/*for (uint32_t i = 0; i < numFlows; ++i) {
    std::string p2phName = "p2ph" + std::to_string(i + 1);
    PointToPointHelper p2phName.c_str();
    p2phName.c_str().SetDeviceAttribute("DataRate", DataRateValue(DataRate(dataRateRemoteHostLink)));
    p2phName.c_str().SetDeviceAttribute("Mtu", UintegerValue(2500));
    p2phName.c_str().SetChannelAttribute("Delay", TimeValue(delayRemoteHostLink));
    internetDevices[i] = p2phName.c_str().Install(pgw, remoteHostContainer.Get(i));
}
*/
// Enable packet capture (PCAP) for all devices
//p2ph.EnablePcapAll("C");

// Create a single NetDeviceContainer to hold all devices
NetDeviceContainer internalNet;
internalNet.Add(enbNetDev); 
for (uint32_t i = 0; i < numFlows; ++i) {
    internalNet.Add(internetDevices[i]);
}
    Ipv4AddressHelper ipv4h;
    ipv4h.SetBase("11.0.0.0", "255.0.0.0");
    Ipv4InterfaceContainer internetIpIfaces = ipv4h.Assign(internalNet);
    
    Ipv4StaticRoutingHelper ipv4RoutingHelper;

    Ptr<Ipv4StaticRouting> pgwRouting = ipv4RoutingHelper.GetStaticRouting(pgw->GetObject<Ipv4>());
    
  for (uint32_t i = 3; i <= numFlows + 2; ++i) {
    std::string ipAddress = "11.0.0." + std::to_string(2 * i - 3);
    pgwRouting->AddHostRouteTo(Ipv4Address(ipAddress.c_str()), i);
  }
  
  std::vector<Ptr<Ipv4StaticRouting>> routingVector(numFlows);
  for (uint32_t i = 0; i < numFlows; ++i) {
    //std::string routingName = "remoteHostStaticRouting" + std::to_string(i + 1);
    routingVector[i] = ipv4RoutingHelper.GetStaticRouting (remoteHostContainer.Get (i)->GetObject<Ipv4>());
    std::string ipAddress1 = "7.0.0." + std::to_string(i + 2);
    routingVector[i]->AddNetworkRouteTo (Ipv4Address(ipAddress1.c_str()), Ipv4Mask("255.0.0.0"), 1);
  }
  
  internet.Install(gridScenario.GetUserTerminals());


    Ipv4InterfaceContainer ueTrafficIpIfaceContainer =
        epcHelper->AssignUeIpv4Address(NetDeviceContainer(ueTrafficNetDevContainer));
    
    // Set the default gateway for the UEs
    for (uint32_t j = 0; j < gridScenario.GetUserTerminals().GetN(); ++j)
    {
        Ptr<Ipv4StaticRouting> ueStaticRouting = ipv4RoutingHelper.GetStaticRouting(gridScenario.GetUserTerminals().Get(j)->GetObject<Ipv4>());
        ueStaticRouting->SetDefaultRoute(epcHelper->GetUeDefaultGatewayAddress(), 1);
        //outFile<<epcHelper->GetUeDefaultGatewayAddress()<<"\n"; this is 7.0.0.1
    }

    // attach UEs to the closest eNB
    nrHelper->AttachToClosestEnb(ueTrafficNetDevContainer, enbNetDev);

  TrafficControlHelper tch;
  
  //tch.Uninstall (m_dumbbell.GetLeft ()->GetDevice (0)); //change

  if (m_isBql)
    {
      tch.SetQueueLimits ("ns3::DynamicQueueLimits");
    }

  m_currentAQM = queueDisc;
  if (queueDisc == "ns3::AdaptiveRedQueueDisc" || queueDisc == "ns3::FengAdaptiveRedQueueDisc" || queueDisc == "ns3::NonLinearRedQueueDisc")
    {
      queueDisc = "ns3::RedQueueDisc";
      tch.SetRootQueueDisc (queueDisc.c_str ());
      m_queue= tch.Install(internalNet).Get(0); 
      if (m_currentAQM == "ns3::AdaptiveRedQueueDisc")
        {
          m_queue->SetAttribute ("ARED", BooleanValue (true));
        }
      else if (m_currentAQM == "ns3::FengAdaptiveRedQueueDisc")
        {
          m_queue->SetAttribute ("FengAdaptive", BooleanValue (true));
        }
      else if (m_currentAQM == "ns3::NonLinearRedQueueDisc")
        {
          m_queue->SetAttribute ("NLRED", BooleanValue (true));
        }
    }
  else
    {
      tch.SetRootQueueDisc (queueDisc.c_str ());
      m_queue = tch.Install(internalNet).Get(0); 
    }

  if (queueDisc == "ns3::RedQueueDisc")
    {
      StaticCast<RedQueueDisc> (m_queue)->AssignStreams (0);
    }
  else if (queueDisc == "ns3::PieQueueDisc")
    {
      StaticCast<PieQueueDisc> (m_queue)->AssignStreams (0);
    }
  m_queue->TraceConnectWithoutContext ("Enqueue", MakeCallback (&EvaluationTopology::PacketEnqueue, this));
  m_queue->TraceConnectWithoutContext ("Dequeue", MakeCallback (&EvaluationTopology::PacketDequeue, this));
  m_queue->TraceConnectWithoutContext ("Drop", MakeCallback (&EvaluationTopology::PacketDrop, this));

  //Ipv4GlobalRoutingHelper::PopulateRoutingTables ();//change
  
  m_QDrecord = 0;
  m_numQDrecord = 0;
  m_lastQDrecord = Time::Min ();
  m_currentAQM.replace (m_currentAQM.begin (), m_currentAQM.begin () + 5, "/");
  AsciiTraceHelper asciiQD;
  std::string default_directory = "aqm-eval-output/";
  std::string data = "/data";
  m_QDfile = asciiQD.CreateFileStream (std::string (default_directory + ScenarioName + data + m_currentAQM + "-qdel.dat").c_str ());
  m_TPrecord = 0;
  m_lastTPrecord = Time::Min ();
  AsciiTraceHelper asciiTP;
  m_TPfile = asciiTP.CreateFileStream (std::string (default_directory + ScenarioName + data + m_currentAQM + "-throughput.dat").c_str ());
  AsciiTraceHelper asciiGP;
  m_GPfile = asciiGP.CreateFileStream (std::string (default_directory + ScenarioName + data + m_currentAQM + "-goodput.dat").c_str ());
  AsciiTraceHelper asciiMD;
  m_metaData = asciiMD.CreateFileStream (std::string (default_directory + ScenarioName + data + m_currentAQM + "-metadata.dat").c_str ());
  AsciiTraceHelper asciiDT;
  m_dropTime = asciiDT.CreateFileStream (std::string (default_directory + ScenarioName + data + m_currentAQM + "-drop.dat").c_str ());
  AsciiTraceHelper asciiET;
  m_enqueueTime = asciiET.CreateFileStream (std::string (default_directory + ScenarioName + data + m_currentAQM + "-enqueue.dat").c_str ());
}

EvaluationTopology::~EvaluationTopology (void)
{
}

void
EvaluationTopology::DestroyConnection ()
{
  m_queue->TraceDisconnectWithoutContext ("Enqueue", MakeCallback (&EvaluationTopology::PacketEnqueue, this));
  m_queue->TraceDisconnectWithoutContext ("Dequeue", MakeCallback (&EvaluationTopology::PacketDequeue, this));
  m_queue->TraceDisconnectWithoutContext ("Drop", MakeCallback (&EvaluationTopology::PacketDrop, this));

  for (uint32_t i = 0; i < m_sinks.size (); i++)
    {
      m_sinks[i]->TraceDisconnectWithoutContext ("Rx", MakeCallback (&EvaluationTopology::PayloadSize, this));
    }
  for (uint32_t i = 0; i < m_sources.size (); i++)
    {
      *m_metaData->GetStream () << "The flow completion time of flow " << (i + 1)
                                << " = "
                                << (m_sources[i]->GetFlowCompletionTime ()).GetSeconds ()
                                << "\n";
    }
}

void
EvaluationTopology::PacketEnqueue (Ptr<const QueueDiscItem> item)
{
  Ptr<Packet> p = item->GetPacket ();
  EvalTimestampTag tag;
  p->AddPacketTag (tag);
  Ptr<const Ipv4QueueDiscItem> iqdi = Ptr<const Ipv4QueueDiscItem> (dynamic_cast<const Ipv4QueueDiscItem *> (PeekPointer (item)));
  *m_enqueueTime->GetStream () << (iqdi->GetHeader ()).GetDestination ()
                               << " "
                               << Simulator::Now ().GetSeconds ()
                               << "\n";
}

void
EvaluationTopology::PacketDequeue (Ptr<const QueueDiscItem> item)
{
  Ptr<Packet> p = item->GetPacket ();
  EvalTimestampTag tag;
  p->RemovePacketTag (tag);
  Time delta = Simulator::Now () - tag.GetTxTime ();
  if (m_lastQDrecord == Time::Min () || Simulator::Now () - m_lastQDrecord > MilliSeconds (10))
    {
      m_lastQDrecord = Simulator::Now ();
      if (m_numQDrecord > 0)
        {
          *m_QDfile->GetStream () << Simulator::Now ().GetSeconds ()
                                  << " "
                                  << (m_QDrecord * 1.0) / (m_numQDrecord * 1.0)
                                  << "\n";
        }
      m_QDrecord = 0;
      m_numQDrecord = 0;
    }
  m_numQDrecord++;
  m_QDrecord += delta.GetMilliSeconds ();
}

void
EvaluationTopology::PacketDrop (Ptr<const QueueDiscItem> item)
{
  Ptr<const Ipv4QueueDiscItem> iqdi = Ptr<const Ipv4QueueDiscItem> (dynamic_cast<const Ipv4QueueDiscItem *> (PeekPointer (item)));
  *m_dropTime->GetStream () << (iqdi->GetHeader ()).GetDestination ()
                            << " "
                            << Simulator::Now ().GetSeconds ()
                            << "\n";
}

void
EvaluationTopology::PayloadSize (Ptr<const Packet> packet, const Address & address)
{
  *m_GPfile->GetStream () << address
                          << " "
                          << Simulator::Now ().GetSeconds ()
                          << " "
                          << packet->GetSize ()
                          <<  "\n";
  if (m_lastTPrecord == Time::Min () || Simulator::Now () - m_lastTPrecord > MilliSeconds (10))
    {
      if (m_TPrecord > 0)
        {
          *m_TPfile->GetStream () << Simulator::Now ().GetSeconds ()
                                  << " "
                                  << (m_TPrecord * 1.0) / (Simulator::Now () - m_lastTPrecord).GetSeconds ()
                                  << "\n";
        }
      m_lastTPrecord = Simulator::Now ();
      m_TPrecord = 0;
    }
  m_TPrecord += packet->GetSize ();
}

ApplicationContainer
EvaluationTopology::CreateFlow (Time senderDelay,
                                std::string senderBW,
                                std::string transport_prot, uint64_t maxPacket,
                                DataRate rate, uint32_t initCwnd)
{
  NS_ASSERT_MSG (m_flowsAdded < m_numFlows, "Trying to create more flows than permitted");
  m_flowsAdded++;

  char tempstr[20];

  sprintf (tempstr, "%d", m_flowsAdded);
  std::string sdelayAddress = std::string ("/ChannelList/") + tempstr + std::string ("/Delay");
  std::string rrBWAddress = std::string ("/NodeList/1/DeviceList/") + tempstr + std::string ("/DataRate");
  std::string srBWAddress = std::string ("/NodeList/0/DeviceList/") + tempstr + std::string ("/DataRate");

  sprintf (tempstr, "%d", m_flowsAdded + 1);
  std::string slBWAddress = std::string ("/NodeList/") + tempstr + std::string ("/DeviceList/0/DataRate");
  std::string socketTypeAddress = std::string ("/NodeList/") + tempstr + std::string ("/$ns3::TcpL4Protocol/SocketType");

  sprintf (tempstr, "%d", m_numFlows + m_flowsAdded);
  std::string rdelayAddress = std::string ("/ChannelList/") + tempstr + std::string ("/Delay");

  sprintf (tempstr, "%d", m_numFlows + m_flowsAdded + 1);
  std::string rlBWAddress = std::string ("/NodeList/") + tempstr + std::string ("/DeviceList/0/DataRate");
/*
  Config::Set (sdelayAddress.c_str (), senderDelay);
  Config::Set (rdelayAddress.c_str (), receiverDelay);
  Config::Set (slBWAddress.c_str (), senderBW);
  Config::Set (srBWAddress.c_str (), senderBW);
  Config::Set (rlBWAddress.c_str (), receiverBW);
  Config::Set (rrBWAddress.c_str (), receiverBW);
*/
//std::string socketTypeAddress = std::string ("/NodeList/") + tempstr + std::string ("/$ns3::TcpL4Protocol/SocketType");
    uint32_t indx = m_flowsAdded - 1;
    p2pHelpers[indx].SetDeviceAttribute("DataRate", DataRateValue(DataRate(senderBW)));
    //p2pHelpers[i].SetDeviceAttribute("Mtu", UintegerValue(2500));
    p2pHelpers[indx].SetChannelAttribute("Delay", TimeValue(senderDelay));
    //std::string p2phN = "p2ph" + std::to_string(m_flowsAdded);
    //p2phN.c_str().SetDeviceAttribute("DataRate", DataRateValue(DataRate(senderBW)));
    //p2phName.SetDeviceAttribute("Mtu", UintegerValue(2500));
    //p2phN.c_str().SetChannelAttribute("Delay", TimeValue(senderDelay));


  if (transport_prot == "udp")
    {
      uint32_t port = 50000;
      AddressValue remoteAddress (InetSocketAddress (ueTrafficIpIfaceContainer.GetAddress(m_flowsAdded - 1), port));
      ApplicationContainer sourceAndSinkApp;
      PacketSinkHelper sinkHelper ("ns3::UdpSocketFactory", InetSocketAddress (ueTrafficIpIfaceContainer.GetAddress(m_flowsAdded - 1), port)); 
      sinkHelper.SetAttribute ("Protocol", TypeIdValue (UdpSocketFactory::GetTypeId ()));

      Ptr<Socket> ns3UdpSocket = Socket::CreateSocket (remoteHostContainer.Get (m_flowsAdded - 1), UdpSocketFactory::GetTypeId ());

      Ptr<EvalApp> app = CreateObject<EvalApp> ();
      app->Setup (ns3UdpSocket, remoteAddress.Get (), m_packetSize, maxPacket * m_packetSize, m_flowsAdded * 2, rate);
      remoteHostContainer.Get(m_flowsAdded - 1)->AddApplication (app);

      sourceAndSinkApp.Add (app);
      sourceAndSinkApp.Add (sinkHelper.Install (ueTrafficNodeContainer.Get (m_flowsAdded - 1)));
      Ptr<Application> appSink = sourceAndSinkApp.Get (1);
      Ptr<PacketSink> psink = Ptr<PacketSink> (dynamic_cast<PacketSink *> (PeekPointer (appSink)));
      psink->TraceConnectWithoutContext ("Rx", MakeCallback (&EvaluationTopology::PayloadSize, this));
      return sourceAndSinkApp;
    }
  else if (transport_prot.compare ("ns3::TcpWestwood") == 0)
    {
      // the default protocol type in ns3::TcpWestwood is WESTWOOD
      Config::Set (socketTypeAddress.c_str (), TypeIdValue (TcpWestwoodPlus::GetTypeId ()));
      Config::Set ("ns3::TcpWestwood::FilterType", EnumValue (TcpWestwoodPlus::TUSTIN));
    }
  else if (transport_prot.compare ("ns3::TcpWestwoodPlus") == 0)
    {
      Config::Set (socketTypeAddress.c_str (), TypeIdValue (TcpWestwoodPlus::GetTypeId ()));
      //Config::Set ("ns3::TcpWestwood::ProtocolType", EnumValue (TcpWestwoodPlus));
      Config::Set ("ns3::TcpWestwood::FilterType", EnumValue (TcpWestwoodPlus::TUSTIN));
    }
  else
    {
      Config::Set (socketTypeAddress.c_str (), TypeIdValue (TypeId::LookupByName (transport_prot)));
    }

  uint32_t port = 50000;
  AddressValue remoteAddress (InetSocketAddress (ueTrafficIpIfaceContainer.GetAddress(m_flowsAdded - 1), port));
  ApplicationContainer sourceAndSinkApp;
  PacketSinkHelper sinkHelper ("ns3::TcpSocketFactory", InetSocketAddress (ueTrafficIpIfaceContainer.GetAddress(m_flowsAdded - 1), port));
  sinkHelper.SetAttribute ("Protocol", TypeIdValue (TcpSocketFactory::GetTypeId ()));

  Ptr<Socket> ns3TcpSocket = Socket::CreateSocket (remoteHostContainer.Get(m_flowsAdded - 1), TcpSocketFactory::GetTypeId ());
  ns3TcpSocket->SetAttribute ("InitialCwnd", UintegerValue (initCwnd));
  ns3TcpSocket->SetAttribute ("SegmentSize", UintegerValue (m_packetSize));

  if (transport_prot.compare ("ns3::TcpNewReno") == 0)
    {
      ns3TcpSocket->SetAttribute ("Sack", BooleanValue (true));
    }
  else
    {
      ns3TcpSocket->SetAttribute ("Sack", BooleanValue (false));
    }

  Ptr<EvalApp> app = CreateObject<EvalApp> ();
  app->Setup (ns3TcpSocket, remoteAddress.Get (), m_packetSize, maxPacket * m_packetSize, m_flowsAdded * 2, rate);
  remoteHostContainer.Get (m_flowsAdded - 1)->AddApplication (app);

  sourceAndSinkApp.Add (app);
  sourceAndSinkApp.Add (sinkHelper.Install (ueTrafficNodeContainer.Get (m_flowsAdded - 1)));
  Ptr<Application> appSink = sourceAndSinkApp.Get (1);
  Ptr<PacketSink> psink = Ptr<PacketSink> (dynamic_cast<PacketSink *> (PeekPointer (appSink)));
  psink->TraceConnectWithoutContext ("Rx", MakeCallback (&EvaluationTopology::PayloadSize, this));
  m_sinks.push_back (psink);
  m_sources.push_back (app);
  return sourceAndSinkApp;
}

} //namespace ns3
